<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculadora</title>
    <link rel="stylesheet" href="estilo.css">
</head>
<body>
    <h2>Calculadora</h2>

    <form method="POST" action="pogama.php">
        <input type="text" name="numero">
        <input type="submit" value="Convertir">
</body>
</html>




<?php

$numero= $_REQUEST['numero'];
$hexadecimal=dechex($numero);
$binario=decbin($numero);
$octal= decoct($numero);
echo "</br>";

if ($binario){
    echo "</br>";
echo "El numero binario es: " . $binario;
}
if ($octal){
    echo "</br>";
echo "El numero en octal es: " . $octal;
}if($hexadecimal){
    echo "</br>";
    echo "El numero en hexadecimal es: " . $hexadecimal;
}

?>

